package kt.distribuidora.sql;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import kt.distribuidora.R;

//import androidx.recyclerview.widget.RecyclerView;

public class AdaptadorPedidos extends RecyclerView.Adapter<AdaptadorPedidos.ClienteViewHolder> {

    Context context;
    ArrayList<Pedido> listaPedidos;
    protected View.OnClickListener onClickListener; //Listener para cada elemento
    protected View.OnLongClickListener onLongClickListener; //Listener largo para cada elemento

    public AdaptadorPedidos(ArrayList<Pedido> listaPedidos) {
        this.listaPedidos = listaPedidos;
    }

    @Override
    public ClienteViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_rv_pedidos, null, false);
        return new ClienteViewHolder(vista);
    }

    @Override
    public void onBindViewHolder( ClienteViewHolder holder, int position) {

        try {

            int idPedido = listaPedidos.get(position).getIdPedido();
            int codigoVendedor = listaPedidos.get(position).getCodigoVendedor();
            String nombreVendedor = listaPedidos.get(position).getNombreVendedor();
            int codigoCliente = listaPedidos.get(position).getCodigoCliente();
            String nombreCliente = listaPedidos.get(position).getNombreCliente();
            int fechaPedido = listaPedidos.get(position).getFechaPedido();
            String comentariosPedido = listaPedidos.get(position).getComentariosPedido();

            if (idPedido == 0) {
                holder.tvPedidosCodigo.setText("No hay Pedidos cargados");
                holder.tvPedidosCodigoVendedorNombre.setText("");
                holder.tvPedidosCodigoClienteNombre.setText("");
                holder.tvPedidosFecha.setText("");
                holder.tvPedidosComentarios.setText("");
                holder.tvPedidosArticulos.setText("");
            } else {
                holder.tvPedidosCodigo.setText("Código: " + idPedido);
                holder.tvPedidosCodigoVendedorNombre.setText("Vendedor: " + codigoVendedor + " - " + nombreVendedor);
                holder.tvPedidosCodigoClienteNombre.setText("Cliente: " + codigoCliente + " - " + nombreCliente);
                String fecnacS = "" + fechaPedido;
                String fecnacSS = fecnacS.substring(6, 8) + "/" + fecnacS.substring(4, 6) + "/" + fecnacS.substring(0, 4);
                holder.tvPedidosFecha.setText("Fecha del Pedido: " + fecnacSS);
                holder.tvPedidosComentarios.setText("Comentarios: " + comentariosPedido);
                holder.tvPedidosArticulos.setText("Artículos: ");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return listaPedidos.size();
    }

    public class ClienteViewHolder extends RecyclerView.ViewHolder {

        public TextView tvPedidosCodigo, tvPedidosCodigoVendedorNombre, tvPedidosCodigoClienteNombre, tvPedidosFecha, tvPedidosComentarios, tvPedidosArticulos;
        public LinearLayout llPedidosArticulos;

        public ClienteViewHolder( View itemView) {
            super(itemView);

            tvPedidosCodigo = (TextView) itemView.findViewById(R.id.tvPedidosCodigo);
            tvPedidosCodigoVendedorNombre = (TextView) itemView.findViewById(R.id.tvPedidosCodigoVendedorNombre);
            tvPedidosCodigoClienteNombre = (TextView) itemView.findViewById(R.id.tvPedidosCodigoClienteNombre);
            tvPedidosFecha = (TextView) itemView.findViewById(R.id.tvPedidosFecha);
            tvPedidosComentarios = (TextView) itemView.findViewById(R.id.tvPedidosComentarios);
            tvPedidosArticulos = (TextView) itemView.findViewById(R.id.tvPedidosArticulos);
            llPedidosArticulos = (LinearLayout) itemView.findViewById(R.id.llPedidosArticulos);

        }
    }

    public void setOnItemClickListener(View.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }
    public void setOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.onLongClickListener = onLongClickListener;
    }
}
