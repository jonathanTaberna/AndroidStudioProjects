package kt.distribuidora.menu_lateral;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import kt.distribuidora.MainActivity;
import kt.distribuidora.R;
import kt.distribuidora.constantes.constantes;

@SuppressLint("ValidFragment")
public class MenuFragment extends Fragment { //implements View.OnClickListener {

    //variables main activity

    private Context contexto;
    private Button btnNuevoPedido;
    private Button btnExportarPedidos;

    NavigationView navigationView;

    //fin variables main activity
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_menu, container, false);

        contexto = container.getContext();

        btnNuevoPedido = (Button) view.findViewById(R.id.btnNuevoPedido);
        btnExportarPedidos = (Button) view.findViewById(R.id.btnExportarPedidos);

        btnNuevoPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) getActivity()).ResultadoBotoneraMainMenu(constantes.RESULT_NUEVO_PEDIDO);
                return;
            }
        });

        return view;
    }

    /*
    @Override
    public void onClick(View v) {
        NuevoPedidoFragment nuevoPedidoFragment = new NuevoPedidoFragment();
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.contenedor, nuevoPedidoFragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
    */
}
