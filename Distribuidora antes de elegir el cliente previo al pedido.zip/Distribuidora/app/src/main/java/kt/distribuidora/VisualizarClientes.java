package kt.distribuidora;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import kt.distribuidora.sql.AdaptadorClientes;
import kt.distribuidora.sql.AdminSQLiteOpenHelper;
import kt.distribuidora.sql.Cliente;

public class VisualizarClientes extends AppCompatActivity {

    RecyclerView rvClientes;
    List<Cliente> listaClientes = new ArrayList<>();
    AdaptadorClientes adaptador;

    private String pathClientes, pathArt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizar_clientes);

        rvClientes = findViewById(R.id.rvClientes);
        rvClientes.setLayoutManager(new GridLayoutManager(this, 1));

        Bundle extras = getIntent().getExtras();
        pathClientes = extras.getString("pathClientes");
        pathArt = extras.getString("pathArt");

        //importarCSV();

    }
/*
    public void importarCSV() {
        limpiarTablas("usuarios");

        //File carpeta = new File(Environment.getExternalStorageDirectory() + "/ExportarSQLiteCSV");

        //String archivoAgenda = carpeta.toString() + "/" + "Usuarios.csv";

            String cadena;
            String[] arreglo;

            try {
                FileReader fileReader = new FileReader(pathClientes);
                BufferedReader bufferedReader = new BufferedReader(fileReader);

                while((cadena = bufferedReader.readLine()) != null) {

                    arreglo = cadena.split(",");

                    AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(VisualizarClientes.this, "dbSistema", null, 1);
                    SQLiteDatabase db = admin.getWritableDatabase();

                    ContentValues registro = new ContentValues();

                    registro.put("codigo", arreglo[1]);
                    registro.put("nombre", arreglo[2]);
                    registro.put("codigoLista", arreglo[3]);
                    registro.put("costo", arreglo[4]);
                    registro.put("facturaConLista", arreglo[5]);

                    int codigo = Integer.getInteger(arreglo[1]);
                    String nombre = arreglo[2];
                    int codigoLista = Integer.getInteger(arreglo[3]);
                    int costo = Integer.getInteger(arreglo[4]);
                    boolean facturaConLista = Boolean.getBoolean(arreglo[5]);

                    listaClientes.add( new Cliente(codigo, nombre, codigoLista, costo, facturaConLista));

                    // los inserto en la base de datos
                    db.insert("clientes", null, registro);

                    db.close();

                    Toast.makeText(VisualizarClientes.this, "SE IMPORTO EXITOSAMENTE", Toast.LENGTH_SHORT).show();

                    adaptador = new AdaptadorClientes(VisualizarClientes.this, listaClientes);
                    rvClientes.setAdapter(adaptador);

                }
            } catch(Exception e) { }

    }

    public void limpiarTablas(String tabla) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(VisualizarClientes.this, "dbSistema", null, 1);
        SQLiteDatabase db = admin.getWritableDatabase();

        admin.borrarRegistros(tabla, db);

        Toast.makeText(VisualizarClientes.this, "Se limpio los registros de la "+tabla, Toast.LENGTH_SHORT).show();
    }
*/
}
