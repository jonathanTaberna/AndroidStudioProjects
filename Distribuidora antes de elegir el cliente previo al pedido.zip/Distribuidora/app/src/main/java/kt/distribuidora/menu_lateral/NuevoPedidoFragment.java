package kt.distribuidora.menu_lateral;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.Layout;
import android.text.TextWatcher;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import kt.distribuidora.R;
import kt.distribuidora.sql.AdminSQLiteOpenHelper;
import kt.distribuidora.sql.Cliente;
import kt.distribuidora.sql.Pedido;
import kt.distribuidora.sql.Vendedor;

public class NuevoPedidoFragment extends Fragment {
    private Context contexto;

    private Spinner spNuevoCliente;
    private TextView tvPedidoNuevoVendedor;
    private EditText edtPedidoNuevoFecha;
    private TextView tvPedidoNuevoComentario;
    private TextView tvPedidoNuevoTotal;
    private ScrollView scrollViewPedidoNuevo;
    private LinearLayout ll1PedidoNuevo;
    private Button btnPedidoNuevoEliminar;
    private Button btnPedidoNuevoGuardar;
    private Button btnPedidoNuevoCancelar;

    private int sYear;
    private int sMonth;
    private int sDay;

    private int cont;
    private double totalPedido;
    private boolean flagEdit;
    private String comentario;

    private AdminSQLiteOpenHelper adminSQLiteOpenHelper;
    private ArrayAdapter<String> arrayAdapter;

    private Boolean editarInfo;
    private int idPedido;
    private int codigoVendedor;
    private String nombreVendedor;
    private int codigoCliente;
    private String nombreCliente;
    private int fechaPedido;
    private String comentariosPedido;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public NuevoPedidoFragment() {
        // Required empty public constructor
    }

    public static NuevoPedidoFragment newInstance(boolean editarInfo, Pedido pedido) {
        NuevoPedidoFragment nuevoPedidoFragment = new NuevoPedidoFragment();
        Bundle args = new Bundle();
        args.putBoolean("editarInfo", editarInfo);
        if (editarInfo) {
            args.putInt("idPedido", pedido.getIdPedido());
            args.putInt("codigoVendedor", pedido.getCodigoVendedor());
            args.putString("nombreVendedor", pedido.getNombreVendedor());
            args.putInt("codigoCliente", pedido.getCodigoCliente());
            args.putString("nombreCliente", pedido.getNombreCliente());
            args.putInt("fechaPedido", pedido.getFechaPedido());
            args.putString("comentariosPedido", pedido.getComentariosPedido());
        }
        nuevoPedidoFragment.setArguments(args);
        return nuevoPedidoFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        contexto = container.getContext();
        //return inflater.inflate(R.layout.fragment_nuevo_pedido, container, false);

        // create ContextThemeWrapper from the original Activity Context with the custom theme
        final Context contextThemeWrapper = new ContextThemeWrapper(getActivity(), android.R.style.Theme_DeviceDefault_Light_Dialog);

        // clone the inflater using the ContextThemeWrapper
        LayoutInflater localInflater = inflater.cloneInContext(contextThemeWrapper);

        // inflate the layout using the cloned inflater, not default inflater
        return localInflater.inflate(R.layout.fragment_nuevo_pedido, container, false);


    }

    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        final Calendar c = Calendar.getInstance();
        sYear = c.get(Calendar.YEAR);
        sMonth = c.get(Calendar.MONTH);
        sMonth++;
        sDay = c.get(Calendar.DAY_OF_MONTH);

        spNuevoCliente = (Spinner) view.findViewById(R.id.spNuevoCliente);
        tvPedidoNuevoVendedor = (TextView) view.findViewById(R.id.tvPedidoNuevoVendedor);
        edtPedidoNuevoFecha = (EditText) view.findViewById(R.id.edtPedidoNuevoFecha);
        tvPedidoNuevoComentario = (TextView) view.findViewById(R.id.tvPedidoNuevoComentario);
        tvPedidoNuevoTotal = (TextView) view.findViewById(R.id.tvPedidoNuevoTotal);
        scrollViewPedidoNuevo = (ScrollView) view.findViewById(R.id.scrollViewPedidoNuevo);
        ll1PedidoNuevo = (LinearLayout) view.findViewById(R.id.ll1PedidoNuevo);

        leerDatosVendedor();
        tvPedidoNuevoVendedor.setText(nombreVendedor);

        btnPedidoNuevoEliminar = (Button) view.findViewById(R.id.btnPedidoNuevoEliminar);
        btnPedidoNuevoGuardar = (Button) view.findViewById(R.id.btnPedidoNuevoGuardar);
        btnPedidoNuevoCancelar = (Button) view.findViewById(R.id.btnPedidoNuevoCancelar);

        btnPedidoNuevoGuardar.setOnClickListener(new View.OnClickListener() {
            View vista = view;
            @Override
            public void onClick(View view) {
                if (guardarPedido(vista)) { //el guardado fue correcto
                    Toast.makeText(contexto, "Guardado exitoso", Toast.LENGTH_SHORT).show();
                    reestablecerCampos(vista);
                }
            }
        });
        btnPedidoNuevoCancelar.setOnClickListener(new View.OnClickListener() {
            View vista = view;
            @Override
            public void onClick(View view) {

                // Build an AlertDialog
                AlertDialog.Builder builder = new AlertDialog.Builder(contexto);

                // Set a title for alert dialog
                builder.setTitle("Cancelar Pedido.");
                builder.setCancelable(false);

                // Ask the final question
                builder.setMessage("Desea cancelar el pedido actual?");

                // Set the alert dialog yes button click listener
                builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Do something when user clicked the Yes button

                        reestablecerCampos(vista);
                    }
                });

                // Set the alert dialog no button click listener
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Do something when No button clicked
                    }
                });

                AlertDialog dialog = builder.create();
                // Display the alert dialog on interface
                dialog.show();


            }
        });

        btnPedidoNuevoEliminar.setVisibility(View.INVISIBLE);
        btnPedidoNuevoEliminar.setOnClickListener(new View.OnClickListener() {
            View vista = view;
            @Override
            public void onClick(View view) {

                // Build an AlertDialog
                AlertDialog.Builder builder = new AlertDialog.Builder(contexto);

                // Set a title for alert dialog
                builder.setTitle("Eliminar Pedido.");
                builder.setCancelable(false);

                // Ask the final question
                builder.setMessage("Desea eliminar el pedido?");

                // Set the alert dialog yes button click listener
                builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Do something when user clicked the Yes button

                        eliminarPedido();
                        reestablecerCampos(vista);
                    }
                });

                // Set the alert dialog no button click listener
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Do something when No button clicked
                    }
                });

                AlertDialog dialog = builder.create();
                // Display the alert dialog on interface
                dialog.show();


            }
        });


        edtPedidoNuevoFecha.setText(generarFecha(sDay,sMonth,sYear));
        edtPedidoNuevoFecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog();
            }
        });


        tvPedidoNuevoComentario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popUpEditText(tvPedidoNuevoComentario.getText().toString());
            }
        });

        cont = 0;
        totalPedido = 0;
        tvPedidoNuevoTotal.setText("$ " + totalPedido);

        llenarSpinerCliente(view);

        spNuevoCliente.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // your code here
                if (cont > 0) {
                    int i = 1;
                    while (i <= cont) {
                        View child = (View) view.findViewById(i) ;
                        ll1PedidoNuevo.removeView(child);
                        i++;
                    }
                }
                cont = 0;
                totalPedido = 0;
                llenarArticulos(ll1PedidoNuevo);
                tvPedidoNuevoTotal.setText("$ " + totalPedido);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }
        });

        editarInfo = getArguments().getBoolean("editarInfo");
        if (editarInfo) {
            btnPedidoNuevoEliminar.setVisibility(View.VISIBLE);
            idPedido = getArguments().getInt("idPedido");
            codigoCliente = getArguments().getInt("codigoCliente");
            nombreCliente = getArguments().getString("nombreCliente");
            fechaPedido = getArguments().getInt("fechaPedido");
            comentariosPedido = getArguments().getString("comentariosPedido");

            setearDatos(idPedido, codigoCliente, nombreCliente, fechaPedido, comentariosPedido);
        }
    }

    private void setearDatos(int idPedido, int codigoCliente, String  nombreCliente, int fechaPedido, String comentariosPedido){
        tvPedidoNuevoVendedor.setText(nombreVendedor);

        String elemento = codigoCliente + " - " + nombreCliente;
        spNuevoCliente.setSelection(arrayAdapter.getPosition(elemento));

        String fechaPedidoS = "" + fechaPedido;
        String fechaPedidoSS = fechaPedidoS.substring(6, 8) + "/" + fechaPedidoS.substring(4, 6) + "/" + fechaPedidoS.substring(0, 4);
        edtPedidoNuevoFecha.setText(fechaPedidoSS);
        tvPedidoNuevoComentario.setText(comentariosPedido);

    }

    private void llenarSpinerCliente(View view) {

        adminSQLiteOpenHelper = new AdminSQLiteOpenHelper(getContext(), "dbSistema", null, 1);
        SQLiteDatabase db = adminSQLiteOpenHelper.getReadableDatabase();
        String query = "SELECT codigo, nombre FROM clientes";
        Cursor cursor = db.rawQuery(query, null);

        int cont = 0;
        ArrayList<String> arraySpinner = new ArrayList<>();

        String elemento = "";
        while (cursor.moveToNext()) {
            cont++;
            int codigo = cursor.getInt(0);
            String nombre = cursor.getString(1);

            elemento = codigo + " - " + nombre;
            arraySpinner.add(elemento);
        }
        cursor.close();

        cursor = db.rawQuery("SELECT dni, nombre FROM clientesNuevos", null);
        elemento = "";
        while (cursor.moveToNext()) {
            cont++;
            long dni = cursor.getLong(0);
            String nombre = cursor.getString(1);
            elemento = dni + " - " + nombre;
            arraySpinner.add(elemento);
        }
        cursor.close();

        if (cont == 0) {
            arraySpinner.add("No hay Clientes cargados");
        }

        arrayAdapter = new ArrayAdapter<String>(contexto,android.R.layout.simple_spinner_item, arraySpinner);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spNuevoCliente.setAdapter(arrayAdapter);

    }

    private void llenarArticulos(LinearLayout linearLayout) {

        String cliente = spNuevoCliente.getSelectedItem().toString();
        if (cliente.equals("No hay Clientes cargados")) {
            Toast.makeText(contexto, "No hay Clientes cargados.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] partes = cliente.split(" - ");
        long codigoCliente = Long.parseLong(partes[0]);

        String query =  "SELECT A.codigo, A.descripcion, A.costo, A.precio, PP.cantidadProducto " +
                        "FROM articulos AS A " +
                        "JOIN clientes AS C " +
                        "ON (A.codigoLista = C.codigoLista) " +
                        "LEFT JOIN productosPedidos AS PP " +
                        "ON (A.codigo = PP.codigoProducto AND PP.idPedido = " + idPedido + ") " +
                        "WHERE C.codigo = " + codigoCliente;
        cargarArticulos(linearLayout, query);

        query =  "SELECT A.codigo, A.descripcion, A.costo, A.precio, PP.cantidadProducto " +
                "FROM articulos AS A " +
                "JOIN clientesNuevos AS CN " +
                "ON (A.codigoLista = CN.categoria) " +
                "LEFT JOIN productosPedidos AS PP " +
                "ON (A.codigo = PP.codigoProducto AND PP.idPedido = " + idPedido + ") " +
                "WHERE CN.dni = " + codigoCliente;
        cargarArticulos(linearLayout, query);
    }

    private void cargarArticulos(LinearLayout linearLayout, String query) {
        adminSQLiteOpenHelper = new AdminSQLiteOpenHelper(getContext(), "dbSistema", null, 1);
        SQLiteDatabase db = adminSQLiteOpenHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        /*
        Toast.makeText(contexto, ""+cursor.getCount(), Toast.LENGTH_LONG).show();
        return;
                        "ON ((A.codigoLista = C.codigoLista AND C.facturaConLista = 'true') " +
                                "OR A.codigoLista = 0 " +
                                "OR C.facturaConLista = 'false' "+
                                */

        while (cursor.moveToNext()) {
            cont++;

            int codigo = cursor.getInt(0);
            String nombre = cursor.getString(1);
            double costo = cursor.getDouble(2);
            final double precio = cursor.getDouble(3);
            int cantidadArt = cursor.getInt(4);

            View child = getLayoutInflater().inflate(R.layout.layout_articulos, null);
            child.setId(cont);

            final TextView desc = (TextView) child.findViewById(R.id.tvNombreArticulo);
            Button btnMas = (Button) child.findViewById(R.id.btnMas);
            final TextView tvCantidadArticulo = (TextView) child.findViewById(R.id.tvCantidadArticulo);
            Button btnMenos = (Button) child.findViewById(R.id.btnMenos);
            final TextView tvCantidad = (TextView) child.findViewById(R.id.tvCantidad);
            final TextView tvPrecio = (TextView) child.findViewById(R.id.tvPrecio);

            final int[] cantidad = {0};
            if (editarInfo && cantidadArt > 0) {
                tvCantidad.setText("" + cantidadArt);
                cantidad[0] = cantidadArt;
                totalPedido += cantidadArt * precio;
            } else {
                tvCantidad.setText("0");
            }
            tvCantidadArticulo.setText("" + cantidad[0]);
            tvPrecio.setText("$ " + precio);
            //desc.setText(nombre + " = $ " + precio);
            desc.setText(codigo + " - " + nombre);
            flagEdit = false;
            btnMas.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //int cantidad = Integer.parseInt(tvCantidadArticulo.getText().toString());
                    cantidad[0] = Integer.parseInt(tvCantidad.getText().toString());
                    cantidad[0] ++;
                    tvCantidad.setText("" + cantidad[0]);
                    flagEdit = true;
                    tvCantidadArticulo.setText("" + cantidad[0]);
                    flagEdit = false;
                    totalPedido += precio;
                    tvPedidoNuevoTotal.setText("$ " + totalPedido);
                    //Toast.makeText(contexto, "bnt mas " + precio, Toast.LENGTH_LONG).show();
                }
            });
            btnMenos.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //int cantidad = Integer.parseInt(tvCantidadArticulo.getText().toString());
                    if (cantidad[0] > 0) {
                        cantidad[0] = Integer.parseInt(tvCantidad.getText().toString());
                        cantidad[0] --;
                        tvCantidad.setText("" + cantidad[0]);
                        flagEdit = true;
                        tvCantidadArticulo.setText("" + cantidad[0]);
                        flagEdit = false;
                        totalPedido -= precio;
                        tvPedidoNuevoTotal.setText("$ " + totalPedido);
                    }
                    //Toast.makeText(contexto, "bnt menos " + precio, Toast.LENGTH_LONG).show();
                }
            });

            tvCantidadArticulo.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        // code to execute when EditText loses focus
                        if (flagEdit == true) {
                            return;
                        }
                        String cantS = tvCantidadArticulo.getText().toString();
                        if (cantS.isEmpty()) {
                            return;
                        }
                        int cant = Integer.parseInt(cantS);
                        if (cantidad[0] > 0) {
                            totalPedido -= precio * cantidad[0];
                        }
                        flagEdit = true;
                        tvCantidadArticulo.setText("" + cant);
                        flagEdit = false;
                        totalPedido += precio * cant;
                        tvPedidoNuevoTotal.setText("$ " + totalPedido);
                        cantidad[0] = cant;
                    }
                }
            });
            /*
            tvCantidadArticulo.setOnEditorActionListener(
                    new EditText.OnEditorActionListener() {
                        @Override
                        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                                    actionId == EditorInfo.IME_ACTION_DONE ||
                                    actionId == EditorInfo.IME_ACTION_NEXT ||
                                    event != null &&
                                            event.getAction() == KeyEvent.ACTION_DOWN &&
                                            event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                                if (event == null || !event.isShiftPressed()) {
                                    // the user is done typing.

                                    if (flagEdit == true) {
                                        return false;
                                    }
                                    String cantS = tvCantidadArticulo.getText().toString();
                                    if (cantS.isEmpty()) {
                                        return false;
                                    }
                                    int cant = Integer.parseInt(cantS);
                                    if (cantidad[0] > 0) {
                                        totalPedido -= precio * cantidad[0];
                                    }
                                    flagEdit = true;
                                    tvCantidadArticulo.setText("" + cant);
                                    flagEdit = false;
                                    totalPedido += precio * cant;
                                    tvPedidoNuevoTotal.setText("$ " + totalPedido);
                                    cantidad[0] = cant;

                                    //tvCantidadArticulo.clearFocus();
                                    tvCantidadArticulo.setFocusableInTouchMode(false);
                                    tvCantidadArticulo.setFocusable(false);
                                    tvCantidadArticulo.setFocusableInTouchMode(true);
                                    tvCantidadArticulo.setFocusable(true);
                                    return true; // consume.
                                }
                            }
                            return false; // pass on to other listeners.
                        }
                    }
            );
            */



            linearLayout.addView(child);

            /*
            LinearLayout ll = new LinearLayout(contexto);
            ll.setOrientation(LinearLayout.HORIZONTAL);
            ll.setPadding(5,5,5,5);

            ViewGroup.LayoutParams params = ll.getLayoutParams();
            if (params != null) {
                params.width= ViewGroup.LayoutParams.MATCH_PARENT;
                params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            } else {
                params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }

            ll.setLayoutParams(params);

            TextView tv = new TextView(contexto);
            tv.setText(nombre + " = $" + precio);
            tv.setWidth(160);
            ll.addView(tv);

            Button b = new Button(contexto);
            //b.setBackgroundResource(R.drawable.mas);
            b.setWidth(2);
            b.setHeight(2);
            ll.addView(b);

            TextView tv2 = new TextView(contexto);
            tv2.setText("0");
            ll.addView(tv2);

            Button b2 = new Button(contexto);
            //b2.setBackgroundResource(R.drawable.menos);
            b.setWidth(2);
            b.setHeight(2);
            ll.addView(b2);

            linearLayout.addView(ll);


             */

        }
        cursor.close();

    }

    private void popUpEditText(String textoCargado) {
        final String[] valor = {""};
        final AlertDialog.Builder builder = new AlertDialog.Builder(contexto);
        builder.setTitle("Comentario");
        builder.setCancelable(false);

        final EditText input = new EditText(contexto);
        input.setText(textoCargado);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        input.setLayoutParams(lp);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // do something here on OK
                comentario = input.getText().toString();
                tvPedidoNuevoComentario.setText(comentario);
                dialog.cancel();
            }
        });
        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }

    private void reestablecerCampos(View vista){
        edtPedidoNuevoFecha.setText(generarFecha(sDay,sMonth,sYear));
        tvPedidoNuevoComentario.setText("");
        if (cont > 0) {
            int i = 1;
            while (i <= cont) {
                View child = (View) vista.findViewById(i) ;
                TextView tvCantidadArticulo = (TextView) child.findViewById(R.id.tvCantidadArticulo);
                final TextView tvCantidad = (TextView) child.findViewById(R.id.tvCantidad);
                final TextView tvPrecio = (TextView) child.findViewById(R.id.tvPrecio);

                int cantidad = 0;
                tvCantidadArticulo.setText("" + cantidad);
                tvCantidad.setText("" + cantidad);
                i++;
            }
        }
        totalPedido = 0;
        tvPedidoNuevoTotal.setText("$ " + totalPedido);
        btnPedidoNuevoEliminar.setVisibility(View.INVISIBLE);
    }

    private void leerDatosVendedor(){
        String retorno = "";

        adminSQLiteOpenHelper = new AdminSQLiteOpenHelper(contexto, "dbSistema", null, 1);
        SQLiteDatabase db = adminSQLiteOpenHelper.getReadableDatabase();
        String query = "SELECT codigo, nombre FROM vendedores";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            codigoVendedor = cursor.getInt(0);
            nombreVendedor = cursor.getString(1);
        }
        cursor.close();
    }

    private void eliminarPedido(){
        adminSQLiteOpenHelper = new AdminSQLiteOpenHelper(getContext(), "dbSistema", null, 1);
        SQLiteDatabase db = adminSQLiteOpenHelper.getWritableDatabase();
        if (idPedido == 0) {
            return;
        }
        String query = "DELETE FROM pedidos WHERE idPedido = " + idPedido;
        db.execSQL(query);

        query = "DELETE FROM productosPedidos WHERE idPedido = " + idPedido;
        db.execSQL(query);

        db.close();
    }

    private boolean guardarPedido(View vista) {
        boolean retorno = false;
        adminSQLiteOpenHelper = new AdminSQLiteOpenHelper(getContext(), "dbSistema", null, 1);
        SQLiteDatabase db = adminSQLiteOpenHelper.getReadableDatabase();
        int idPedido = 0;
        //Obtenemos el ultimo ID de pedidos para poder generar uno nuevo
        String query = "SELECT idPedido " +
                "FROM pedidos " +
                "ORDER BY idPedido DESC";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            idPedido = cursor.getInt(0);
        }
        idPedido++;
        cursor.close();

        SQLiteDatabase db2 = adminSQLiteOpenHelper.getWritableDatabase();
        adminSQLiteOpenHelper.crearTabla("productosPedidos", db2);
        adminSQLiteOpenHelper.crearTabla("pedidos", db2);

        int codigoCliente = 0;
        String nombreCliente = "";
        int fechaPedido = 0;
        String comentariosPedido = "";

        //nombreVendedor = tvPedidoNuevoVendedor.getText().toString();

        String cliente = spNuevoCliente.getSelectedItem().toString();
        if (cliente.equals("No hay Clientes cargados")) {
            Toast.makeText(contexto, "No hay Clientes cargados.", Toast.LENGTH_LONG).show();
            return retorno;
        }
        String[] partes = cliente.split(" - ");
        codigoCliente = Integer.parseInt(partes[0]);
        nombreCliente = partes[1];
        String fechaPedidoS = edtPedidoNuevoFecha.getText().toString();
        partes = fechaPedidoS.split("/");
        int dia = Integer.parseInt(partes[0]);
        int mes = Integer.parseInt(partes[1]);
        int ano = Integer.parseInt(partes[2]);
        String diaS;
        if (dia < 10) {
            diaS = "0" + dia;
        } else {
            diaS = "" + dia;
        }
        String mesS;
        if (mes < 10) {
            mesS = "0" + mes;
        } else {
            mesS = "" + mes;
        }

        fechaPedido = Integer.parseInt("" + ano + mesS + diaS);
        comentariosPedido = tvPedidoNuevoComentario.getText().toString();

        ContentValues registro = new ContentValues();
        int result = 0;
        boolean primerInsert = true;

        int codigoProducto = 0;
        String nombreProducto = "";
        int cantidadProducto = 0;
        double precioProducto = 0;

        if (cont > 0) {
            int i = 1;
            while (i <= cont) {
                View child = (View) vista.findViewById(i) ;
                TextView tvNombreArticulo = (TextView) child.findViewById(R.id.tvNombreArticulo);
                TextView tvCantidadArticulo = (TextView) child.findViewById(R.id.tvCantidadArticulo);
                final TextView tvCantidad = (TextView) child.findViewById(R.id.tvCantidad);
                final TextView tvPrecio = (TextView) child.findViewById(R.id.tvPrecio);

                codigoProducto = 0;
                nombreProducto = "";
                cantidadProducto = 0;
                precioProducto = 0;

                String codigoS = tvNombreArticulo.getText().toString();
                String[] partes2 = codigoS.split(" - ");
                codigoProducto = Integer.parseInt(partes2[0]);
                nombreProducto = partes2[1];
                String cantidadS = tvCantidadArticulo.getText().toString();
                if (!cantidadS.isEmpty()) {
                    cantidadProducto = Integer.parseInt(cantidadS);
                }
                String precioS = tvPrecio.getText().toString();
                precioS = precioS.substring(2);
                //precioS = "50.00";
                System.out.println(Double.parseDouble(precioS));
                //System.out.println(Double.valueOf(precioS));
                if (!precioS.isEmpty()) {
                    precioProducto = Double.parseDouble(precioS);
                }

                if (cantidadProducto == 0) {
                    i++;
                    continue;
                }

                if (primerInsert) {
                    registro.clear();
                    registro.put("idPedido", idPedido);
                    registro.put("codigoVendedor", codigoVendedor);
                    registro.put("nombreVendedor", nombreVendedor);
                    registro.put("codigoCliente", codigoCliente);
                    registro.put("nombreCliente", nombreCliente);
                    registro.put("fechaPedido", fechaPedido);
                    registro.put("comentariosPedido", comentariosPedido);
                    result = (int) db.insert("pedidos", null, registro);
                    if (result < 0) { //error al insertar
                        Toast.makeText(contexto, "Error al guardar los datos del Pedido -1-", Toast.LENGTH_SHORT).show();
                        return retorno;
                    }
                    result = 0;
                    primerInsert = false;
                }

                registro.clear();
                registro.put("idPedido", idPedido);
                registro.put("codigoProducto", codigoProducto);
                registro.put("nombreProducto", nombreProducto);
                registro.put("cantidadProducto", cantidadProducto);
                registro.put("precioProducto", precioProducto);

                result = (int) db.insert("productosPedidos", null, registro);
                if (result < 0) { //error al insertar
                    break;
                }
                i++;
            }
        }
        if (result < 0) { //error al insertar
            Toast.makeText(contexto, "Error al guardar los datos del Pedido -2-", Toast.LENGTH_SHORT).show();
            return retorno;
        }

        retorno = true;

        return retorno;
    }

    private void showDatePickerDialog() {

        String [] dma = edtPedidoNuevoFecha.getText().toString().split("/");

        int anio = Integer.parseInt(dma[2]);
        int mes = Integer.parseInt(dma[1]) - 1; //los meses comienzan desde 0
        int dia = Integer.parseInt(dma[0]);

        DatePickerFragment newFragment = DatePickerFragment.newInstance(new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // +1 because january is zero
                String selectedDate = generarFecha(day, month+1, year);
                edtPedidoNuevoFecha.setText(selectedDate);
            }
        }, anio, mes, dia);
        newFragment.show(getActivity().getSupportFragmentManager(), "datePicker");
    }

    private String generarFecha(int dia, int mes, int anio){
        String fecha = "";

        String diaS;
        if (dia < 10) {
            diaS = "0" + dia;
        } else {
            diaS = "" + dia;
        }
        String mesS;
        if (mes < 10) {
            mesS = "0" + mes;
        } else {
            mesS = "" + mes;
        }

        fecha = diaS + "/" + mesS + "/" + anio;

        return fecha;
    }

}