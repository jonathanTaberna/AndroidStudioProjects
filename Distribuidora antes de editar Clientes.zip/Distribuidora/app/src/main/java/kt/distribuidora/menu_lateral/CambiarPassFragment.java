package kt.distribuidora.menu_lateral;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import kt.distribuidora.R;

public class CambiarPassFragment extends Fragment {

    private Context contexto;

    private Button btnCambiarPassAceptar;
    private Button btnCambiarPassCancelar;
    private EditText edtPasswordVieja;
    private EditText edtPasswordNueva;
    private EditText edtPasswordConfirmar;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        contexto = container.getContext();
        return inflater.inflate(R.layout.activity_cambiar_pass, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        btnCambiarPassAceptar = (Button) view.findViewById(R.id.btnCambiarPassAceptar);
        btnCambiarPassCancelar = (Button) view.findViewById(R.id.btnCambiarPassCancelar);

        edtPasswordVieja = (EditText) view.findViewById(R.id.edtPasswordVieja);
        edtPasswordNueva = (EditText) view.findViewById(R.id.edtPasswordNueva);
        edtPasswordConfirmar = (EditText) view.findViewById(R.id.edtPasswordConfirmar);

        btnCambiarPassAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        btnCambiarPassCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }
}
