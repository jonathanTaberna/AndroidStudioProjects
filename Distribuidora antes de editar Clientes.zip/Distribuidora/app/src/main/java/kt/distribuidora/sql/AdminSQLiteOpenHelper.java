package kt.distribuidora.sql;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AdminSQLiteOpenHelper extends SQLiteOpenHelper {


    private String createTablaClientesNuevos = "CREATE TABLE IF NOT EXISTS clientesNuevos(" +
                                                "dni INTEGER PRIMARY KEY," +
                                                "nombre TEXT," +
                                                "correo TEXT," +
                                                "telefono TEXT," +
                                                "direccion TEXT," +
                                                "codpos INTEGER," +
                                                "localidad TEXT," +
                                                "fecnac INTEGER" +
                                                ")";
    private String dropTablaClientesNuevos = "DROP TABLE IF EXISTS clientesNuevos";

    private String createTablaClientes = "CREATE TABLE IF NOT EXISTS clientes(" +
                                    "codigo INTEGER PRIMARY KEY," +
                                    "nombre TEXT," +
                                    "codigoLista INTEGER," +
                                    "costo INTEGER," +
                                    "facturaConLista BOOLEAN" +
                                    ")";
    private String dropTablaClientes = "DROP TABLE IF EXISTS clientes";
    private String createTablaArticulos = "CREATE TABLE IF NOT EXISTS articulos(" +
                                    "codigo INTEGER PRIMARY KEY," +
                                    "descripcion TEXT," +
                                    "costo DECIMAL(10,2)," +
                                    "codigoLista INTEGER," +
                                    "precio DECIMAL(10,2)" +
                                    ")";
    private String dropTablaArticulos = "DROP TABLE IF EXISTS articulos";
    private String createTablaVendedores = "CREATE TABLE IF NOT EXISTS vendedores(" +
                                    "codigo INTEGER PRIMARY KEY," +
                                    "nombre TEXT" +
                                    ")";
    private String dropTablaVendedores = "DROP TABLE IF EXISTS vendedores";


    public AdminSQLiteOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(createTablaClientesNuevos);
        db.execSQL(createTablaClientes);
        db.execSQL(createTablaArticulos);
        db.execSQL(createTablaVendedores);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }

    public void borrarRegistros(String tabla, SQLiteDatabase db) {
        db.execSQL("DELETE FROM "+tabla);
    }

    public void borrarTablas(SQLiteDatabase db) {
        db.execSQL(dropTablaClientesNuevos);
        db.execSQL(createTablaClientesNuevos);

        db.execSQL(dropTablaClientes);
        db.execSQL(createTablaClientes);

        db.execSQL(dropTablaArticulos);
        db.execSQL(createTablaArticulos);

        db.execSQL(dropTablaVendedores);
        db.execSQL(createTablaVendedores);
    }

    public void crearTablas(SQLiteDatabase db) {
        db.execSQL(createTablaClientesNuevos);
        db.execSQL(createTablaClientes);
        db.execSQL(createTablaArticulos);
        db.execSQL(createTablaVendedores);

    }
}
