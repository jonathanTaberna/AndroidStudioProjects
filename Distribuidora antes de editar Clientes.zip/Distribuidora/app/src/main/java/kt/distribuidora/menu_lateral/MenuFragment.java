package kt.distribuidora.menu_lateral;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import kt.distribuidora.R;

@SuppressLint("ValidFragment")
public class MenuFragment extends Fragment {

    //variables main activity

    private Context contexto;
    private Button btnNuevoPedido;
    private Button btnExportarPedidos;

    NavigationView navigationView;

    //fin variables main activity
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_menu, container, false);

        contexto = container.getContext();

        btnNuevoPedido = (Button) view.findViewById(R.id.btnNuevoPedido);
        btnExportarPedidos = (Button) view.findViewById(R.id.btnExportarPedidos);
        /*
        btnNuevoPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setearEnable(false);
            }
        });
        */
        // Inflate the layout for this fragment
        /*
        navigationView = (NavigationView) view.findViewById(R.id.nav_view);
        View hView =  navigationView.getHeaderView(0);
        ImageView imgvw = (ImageView)hView.findViewById(R.id.ivNavigator);

        imgvw.setImageResource(R.drawable.unnamed);
        */

        return view;
    }

}
