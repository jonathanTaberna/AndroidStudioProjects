package kt.distribuidora.menu_lateral;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.icu.util.Calendar;
import android.widget.Toast;

import kt.distribuidora.R;
import kt.distribuidora.sql.AdminSQLiteOpenHelper;

@SuppressLint("ValidFragment")
public class NuevoClienteFragment  extends Fragment {

    private Context contexto;

    private EditText edtNuevoClienteDni;
    private EditText edtNuevoClienteNombre;
    private EditText edtNuevoClienteCorreo;
    private EditText edtNuevoClienteTelefono;
    private EditText edtNuevoClienteDireccion;
    private EditText edtNuevoClienteLocalidad;
    private EditText edtNuevoClienteFechaNacimiento;
    private EditText edtNuevoClienteCodpos;

    private Button btnNuevoClienteCancelar;
    private Button btnNuevoClienteAceptar;

    private int sYear;
    private int sMonth;
    private int sDay;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        contexto = container.getContext();
        return inflater.inflate(R.layout.activity_nuevo_cliente, container, false);
        /*
        View view = inflater.inflate(R.layout.activity_nuevo_cliente, container, false);

        contexto = container.getContext();

        btnNuevoClienteAceptar = (Button) view.findViewById(R.id.btnNuevoClienteAceptar);
        btnNuevoClienteCancelar = (Button) view.findViewById(R.id.btnNuevoClienteCancelar);

        edtNuevoClienteNombre = (EditText) view.findViewById(R.id.edtNuevoClienteNombre);
        edtNuevoClienteCorreo = (EditText) view.findViewById(R.id.edtNuevoClienteCorreo);
        edtNuevoClienteTelefono = (EditText) view.findViewById(R.id.edtNuevoClienteTelefono);
        edtNuevoClienteDireccion = (EditText) view.findViewById(R.id.edtNuevoClienteDireccion);
        edtNuevoClienteLocalidad = (EditText) view.findViewById(R.id.edtNuevoClienteLocalidad);
        edtNuevoClienteFechaNacimiento = (EditText) view.findViewById(R.id.edtNuevoClienteFechaNacimiento);

        return view;
        */
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Calendar c = Calendar.getInstance();
        sYear = c.get(Calendar.YEAR);
        sMonth = c.get(Calendar.MONTH);
        sMonth++;
        sDay = c.get(Calendar.DAY_OF_MONTH);

        btnNuevoClienteAceptar = (Button) view.findViewById(R.id.btnNuevoClienteAceptar);
        btnNuevoClienteCancelar = (Button) view.findViewById(R.id.btnNuevoClienteCancelar);

        edtNuevoClienteDni = (EditText) view.findViewById(R.id.edtNuevoClienteDni);
        edtNuevoClienteNombre = (EditText) view.findViewById(R.id.edtNuevoClienteNombre);
        edtNuevoClienteCorreo = (EditText) view.findViewById(R.id.edtNuevoClienteCorreo);
        edtNuevoClienteTelefono = (EditText) view.findViewById(R.id.edtNuevoClienteTelefono);
        edtNuevoClienteDireccion = (EditText) view.findViewById(R.id.edtNuevoClienteDireccion);
        edtNuevoClienteLocalidad = (EditText) view.findViewById(R.id.edtNuevoClienteLocalidad);
        edtNuevoClienteCodpos = (EditText) view.findViewById(R.id.edtNuevoClienteCodpos);
        edtNuevoClienteFechaNacimiento = (EditText) view.findViewById(R.id.edtNuevoClienteFechaNacimiento);

        btnNuevoClienteAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String dniS = edtNuevoClienteDni.getText().toString();
                if (dniS.isEmpty()) {
                    edtNuevoClienteDni.setError(getString(R.string.error_field_required));
                    edtNuevoClienteDni.requestFocus();
                    return;
                }
                int dni = Integer.parseInt(dniS);
                if (dni <= 0) {
                    //Toast.makeText(contexto, "El DNI debe ser Positivo", Toast.LENGTH_SHORT).show();
                    edtNuevoClienteDni.setError(getString(R.string.error_dni_positivo));
                    edtNuevoClienteDni.requestFocus();
                    return;
                }
                String nombre = edtNuevoClienteNombre.getText().toString();
                if (nombre.isEmpty()) {
                    edtNuevoClienteNombre.setError(getString(R.string.error_field_required));
                    edtNuevoClienteNombre.requestFocus();
                    return;
                }

                String correo = edtNuevoClienteCorreo.getText().toString();
                String telefono = edtNuevoClienteTelefono.getText().toString();
                String direccion = edtNuevoClienteDireccion.getText().toString();
                String localidad = edtNuevoClienteLocalidad.getText().toString();
                String codposS = edtNuevoClienteCodpos.getText().toString();
                int codpos = 0;
                if (!codposS.isEmpty()) {
                    codpos = Integer.parseInt(codposS);
                }
                String fecnacS = edtNuevoClienteFechaNacimiento.getText().toString();
                String[] partes = fecnacS.split("/");
                int dia = Integer.parseInt(partes[0]);
                int mes = Integer.parseInt(partes[1]);
                int ano = Integer.parseInt(partes[2]);

                String diaS;
                if (dia < 10) {
                    diaS = "0" + dia;
                } else {
                    diaS = "" + dia;
                }
                String mesS;
                if (mes < 10) {
                    mesS = "0" + mes;
                } else {
                    mesS = "" + mes;
                }

                int fecnac = Integer.parseInt("" + ano + mesS + diaS);


                try {
                    ContentValues registro = new ContentValues();

                    registro.put("dni", dni);
                    registro.put("nombre", nombre);
                    registro.put("correo", correo);
                    registro.put("telefono", telefono);
                    registro.put("direccion", direccion);
                    registro.put("localidad", localidad);
                    registro.put("codpos", codpos);
                    registro.put("fecnac", fecnac);

                    AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(contexto, "dbSistema", null, 1);
                    SQLiteDatabase db = admin.getWritableDatabase();
                    db.insert("clientesNuevos", null, registro);
                    db.close();

                    Toast.makeText(contexto, "Los Datos del Cliente nuevo fueron Guardados EXITOSAMENTE", Toast.LENGTH_SHORT).show();


                    edtNuevoClienteDni.setText("");
                    edtNuevoClienteNombre.setText("");
                    edtNuevoClienteCorreo.setText("");
                    edtNuevoClienteTelefono.setText("");
                    edtNuevoClienteDireccion.setText("");
                    edtNuevoClienteLocalidad.setText("");
                    edtNuevoClienteCodpos.setText("");
                    edtNuevoClienteFechaNacimiento.setText(sDay+"/"+sMonth+"/"+sYear+"");
                    edtNuevoClienteDni.requestFocus();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        btnNuevoClienteCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                edtNuevoClienteDni.setText("");
                edtNuevoClienteNombre.setText("");
                edtNuevoClienteCorreo.setText("");
                edtNuevoClienteTelefono.setText("");
                edtNuevoClienteDireccion.setText("");
                edtNuevoClienteLocalidad.setText("");
                edtNuevoClienteCodpos.setText("");
                edtNuevoClienteFechaNacimiento.setText(sDay+"/"+sMonth+"/"+sYear+"");
            }
        });

        edtNuevoClienteFechaNacimiento.setText(sDay+"/"+sMonth+"/"+sYear+"");
        edtNuevoClienteFechaNacimiento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog();
            }
        });
    }
    private void showDatePickerDialog() {

        String [] dma = edtNuevoClienteFechaNacimiento.getText().toString().split("/");

        int anio = Integer.parseInt(dma[2]);
        int mes = Integer.parseInt(dma[1]) - 1; //los meses comienzan desde 0
        int dia = Integer.parseInt(dma[0]);

        DatePickerFragment newFragment = DatePickerFragment.newInstance(new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // +1 because january is zero
                final String selectedDate = String.valueOf(day) + "/" + String.valueOf((month+1)) + "/" + String.valueOf(year);
                edtNuevoClienteFechaNacimiento.setText(selectedDate);
            }
        }, anio, mes, dia);
        newFragment.show(getActivity().getSupportFragmentManager(), "datePicker");
    }
}
