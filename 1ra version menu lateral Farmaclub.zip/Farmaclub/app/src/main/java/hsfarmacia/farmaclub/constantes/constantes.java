package hsfarmacia.farmaclub.constantes;

public class constantes {

    //preferencias
    public static String farmaclubConfig = "farmaclub.config";

    //constantes
    public static String CONFIG_NOT_FOUND = "CONFIG_NOT_FOUND";
    public static String CONFIG_FOUND = "CONFIG_FOUND";
    public static int RESULT_NUEVO_USUARIO = 111;
    public static int RESULT_MAIN_ACTIVITY = 222;
    public static int CANTIDAD_PRODUCTOS_LISTA = 10;

    public static String lanzoni = "http://192.168.2.209:8080/restfull-web-services-app-master/rest/user/";
    public static String lanzoniProductos = "http://192.168.2.209:8080/restfull-web-services-app-master/rest/product/";
    public static String flavio  = "http://192.168.2.50:8080/farmaclubserver/rest/user/"; //existeusu
    public static String flavioProductos  = "http://192.168.2.50:8080/farmaclubserver/rest/product/"; //existeusu
    public static String hsServer = "http://192.168.2.121:8080/farmaclubserver/rest/user/";
    public static String hsServerNombre = "http://highsoft.no-ip.org:8080/farmaclubserver/rest/user/";
    public static String hsServerNombreProductos = "http://highsoft.no-ip.org:8080/farmaclubserver/rest/product/";

    public static String pathConnection = hsServerNombre;
    public static String pathConnectionProductos = hsServerNombreProductos;

    public static String pdfName = "FarmaClub Terminos y Condiciones.pdf";


}
