package hsfarmacia.farmaclub;

import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import hsfarmacia.farmaclub.menu_lateral.CanjeFragment;
import hsfarmacia.farmaclub.menu_lateral.MisDatosFragment;
import hsfarmacia.farmaclub.menu_lateral.NovedadesFragment;
import hsfarmacia.farmaclub.menu_lateral.PromocionesFragment;

public class MainActivity2 extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private FragmentManager fragmentManager = getSupportFragmentManager();
    private String fragmentActual = "";
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        fragmentActual = "canje";
        fragmentManager.beginTransaction().replace(R.id.contenedor, new CanjeFragment()).commit();
        //toolbar.getMenu().findItem(R.id.main2_action_settings).setVisible(true);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_activity2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_canje) {
            if (fragmentActual != "canje") {
                fragmentActual = "canje";
                fragmentManager.beginTransaction().replace(R.id.contenedor, new CanjeFragment()).commit();
                toolbar.getMenu().findItem(R.id.main2_action_settings).setVisible(true);
            }
            // Handle the camera action
        } else if (id == R.id.nav_promociones) {
            fragmentActual = "promociones";
            fragmentManager.beginTransaction().replace(R.id.contenedor, new PromocionesFragment()).commit();
            toolbar.getMenu().findItem(R.id.main2_action_settings).setVisible(false);

        } else if (id == R.id.nav_mis_datos) {
            fragmentActual = "mis_datos";
            fragmentManager.beginTransaction().replace(R.id.contenedor, new MisDatosFragment()).commit();
            toolbar.getMenu().findItem(R.id.main2_action_settings).setVisible(false);

        } else if (id == R.id.nav_novedades) {
            fragmentActual = "novedades";
            fragmentManager.beginTransaction().replace(R.id.contenedor, new NovedadesFragment()).commit();
            toolbar.getMenu().findItem(R.id.main2_action_settings).setVisible(false);

        } else if (id == R.id.nav_cerrar_sesion) {
            setResult(RESULT_FIRST_USER);
            finish();

        } else if (id == R.id.nav_salir) {
            setResult(RESULT_CANCELED);
            finish();

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
