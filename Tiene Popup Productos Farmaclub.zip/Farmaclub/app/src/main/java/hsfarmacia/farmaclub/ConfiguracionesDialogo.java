package hsfarmacia.farmaclub;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.RadioButton;

public class ConfiguracionesDialogo {

    public interface FinalizoConfiguracionesDialogo{
        void ResultadoConfiguracionesDialogo(String orden, String orderBy);
    }
    private FinalizoConfiguracionesDialogo interfaz;
    public ConfiguracionesDialogo(Context contexto, FinalizoConfiguracionesDialogo actividad) {
        interfaz = actividad;

        final Dialog dialogo = new Dialog(contexto);
        dialogo.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogo.setCancelable(false);
        //dialogo.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogo.setContentView(R.layout.configuraciones_dialogo);

        final RadioButton rbNombre = (RadioButton) dialogo.findViewById(R.id.rbNombre);
        final RadioButton rbPuntos = (RadioButton) dialogo.findViewById(R.id.rbPuntos);
        final RadioButton rbAsc = (RadioButton) dialogo.findViewById(R.id.rbAsc);
        final RadioButton rbDesc = (RadioButton) dialogo.findViewById(R.id.rbDesc);
        Button btnDialogAceptar = (Button) dialogo.findViewById(R.id.btnDialogAceptar);
        Button btnDialogCancelar = (Button) dialogo.findViewById(R.id.btnDialogCancelar);

        btnDialogAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String orden = "";
                String orderBy = "";
                if(rbNombre.isChecked()) {
                   orden = "nombre";
                }
                if (rbPuntos.isChecked()){
                    orden = "puntos";
                }
                if (rbAsc.isChecked()){
                    orderBy = "asc";
                }
                if (rbDesc.isChecked()){
                    orderBy = "desc";
                }
                interfaz.ResultadoConfiguracionesDialogo(orden, orderBy);
                dialogo.dismiss();
            }
        });
        btnDialogCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogo.dismiss();
            }
        });
        dialogo.show();
    }
}
