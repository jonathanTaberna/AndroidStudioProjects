package kt.distribuidora.fragments_datos_cargados;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import kt.distribuidora.MainActivity;
import kt.distribuidora.R;
import kt.distribuidora.adaptadores.AdaptadorPedidos;
import kt.distribuidora.sql.AdminSQLiteOpenHelper;
import kt.distribuidora.elementos.Articulo;
import kt.distribuidora.elementos.Pedido;

public class PedidosCargadosFragment extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    private RecyclerView recyclerPedidosCargados;
    private ArrayList<Pedido> listaPedidos;

    private AdminSQLiteOpenHelper adminSQLiteOpenHelper;

    public PedidosCargadosFragment() {
        // Required empty public constructor
    }

    public static PedidosCargadosFragment newInstance(String param1, String param2) {
        PedidosCargadosFragment fragment = new PedidosCargadosFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View vista = inflater.inflate(R.layout.fragment_pedidos_cargados, container, false);
        recyclerPedidosCargados= (RecyclerView) vista.findViewById(R.id.recyclerPedidosCargados);

        listaPedidos = new ArrayList<>();
        recyclerPedidosCargados.setLayoutManager(new LinearLayoutManager(getContext()));

        llenarLista();

        AdaptadorPedidos adaptadorPedidos = new AdaptadorPedidos(listaPedidos);
        recyclerPedidosCargados.setAdapter(adaptadorPedidos);

        adaptadorPedidos.setOnLongClickListener(new View.OnLongClickListener(){
            @Override
            public boolean onLongClick(View v)
            {
                int id = (int) recyclerPedidosCargados.getChildAdapterPosition(v);
                Pedido pedido = listaPedidos.get(id);
                ((MainActivity) getActivity()).ResultadoPedido(pedido);
                return true;
            }
        });
        return vista;
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }
    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }

    public void llenarLista(){

        adminSQLiteOpenHelper = new AdminSQLiteOpenHelper(getContext(), "dbSistema", null, 1);
        SQLiteDatabase db = adminSQLiteOpenHelper.getReadableDatabase();

        Pedido pedido = null;

        String query = "SELECT idPedido, codigoVendedor, nombreVendedor, codigoCliente, nombreCliente, fechaPedido, comentariosPedido " +
                        "FROM pedidos";
        Cursor cursor = db.rawQuery(query, null);
        int cont = 0;

        while (cursor.moveToNext()) {
            pedido = new Pedido();

            int idPedido = cursor.getInt(0);
            pedido.setIdPedido(cursor.getInt(0));
            pedido.setCodigoVendedor(cursor.getInt(1));
            pedido.setNombreVendedor(cursor.getString(2));
            pedido.setCodigoCliente(cursor.getInt(3));
            pedido.setNombreCliente(cursor.getString(4));
            pedido.setFechaPedido(cursor.getInt(5));
            pedido.setComentariosPedido(cursor.getString(6));

            ArrayList<Articulo> listaArticulos = new ArrayList<>();
            SQLiteDatabase dbArt = adminSQLiteOpenHelper.getReadableDatabase();
            String queryArt = "SELECT codigoProducto, nombreProducto, cantidadProducto, precioProducto " +
                                "FROM productosPedidos " +
                                "WHERE idPedido = " + idPedido ;
            Cursor cursorArt = dbArt.rawQuery(queryArt, null);
            while (cursorArt.moveToNext()) {
                Articulo articulo = new Articulo();
                int codigo = cursorArt.getInt(0);
                String descripcion = cursorArt.getString(1);
                int cantidad = cursorArt.getInt(2);
                double precio = cursorArt.getDouble(3);

                articulo.setCodigo(codigo);
                articulo.setDescripcion(descripcion);
                articulo.setCantidad(cantidad);
                articulo.setPrecio(precio);
                listaArticulos.add(articulo);
            }
            cursorArt.close();

            pedido.setListaArticulos(listaArticulos);
            listaPedidos.add(pedido);
            cont++;
        }

        cursor.close();
        if (cont == 0) {
            //Toast.makeText(getContext(), "No hay Clientes Cargados", Toast.LENGTH_SHORT).show();
            pedido = new Pedido();
            listaPedidos.add(pedido);
        }
    }
}
