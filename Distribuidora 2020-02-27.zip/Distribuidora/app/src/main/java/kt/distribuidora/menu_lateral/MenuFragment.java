package kt.distribuidora.menu_lateral;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

import kt.distribuidora.MainActivity;
import kt.distribuidora.R;
import kt.distribuidora.constantes.constantes;
import kt.distribuidora.fragments_secundarios.SeleccionarClienteDialogo;
import kt.distribuidora.sql.AdminSQLiteOpenHelper;
import kt.distribuidora.elementos.Articulo;

@SuppressLint("ValidFragment")
public class MenuFragment extends Fragment { //implements View.OnClickListener {

    //variables main activity

    private Context contexto;
    private Button btnNuevoPedido;
    private Button btnExportarPedidos;

    private SeleccionarClienteDialogo.FinalizoSeleccionarClienteDialogo finalizoSeleccionarClienteDialogo;

    NavigationView navigationView;

    //fin variables main activity
    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_menu, container, false);

        contexto = container.getContext();

        btnNuevoPedido = (Button) view.findViewById(R.id.btnNuevoPedido);
        btnExportarPedidos = (Button) view.findViewById(R.id.btnExportarPedidos);

        finalizoSeleccionarClienteDialogo = new SeleccionarClienteDialogo.FinalizoSeleccionarClienteDialogo() {
            @Override
            public void ResultadoSeleccionarClienteDialogo(long codigoCliente, String nombreCliente) {
                Toast.makeText(contexto,"codigo cliente: " + codigoCliente + " - " + nombreCliente, Toast.LENGTH_LONG).show();
                ((MainActivity) getActivity()).ResultadoBotoneraMainMenu(constantes.RESULT_NUEVO_PEDIDO, codigoCliente, nombreCliente);

            }
        };
        btnNuevoPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                new SeleccionarClienteDialogo(contexto, finalizoSeleccionarClienteDialogo, null, null);


                //((MainActivity) getActivity()).ResultadoBotoneraMainMenu(constantes.RESULT_NUEVO_PEDIDO);
                return;
            }
        });

        btnExportarPedidos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generarCSVpedidos();
            }
        });

        return view;
    }


    private void generarCSVpedidos() {
        try {
            String baseFolder;
// check if external storage is available
            if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                baseFolder = String.valueOf(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));
            }
// revert to using internal storage (not sure if there's an equivalent to the above)
            else {
                baseFolder = contexto.getFilesDir().getAbsolutePath();
            }

            Calendar c = Calendar.getInstance();
            int sYear = c.get(Calendar.YEAR);
            int sMonth = c.get(Calendar.MONTH);
            sMonth++;
            int sDay = c.get(Calendar.DAY_OF_MONTH);
            String ssMonth, ssDay;
            if (sMonth < 10) {
                ssMonth = "0" + sMonth;
            } else {
                ssMonth = "" + sMonth;
            }
            if (sDay < 10) {
                ssDay = "0" + sDay;
            } else {
                ssDay = "" + sDay;
            }

            String nombreArch = "Pedido " + sYear + "-" + ssMonth + "-" + ssDay + "-" + ".CSV";

            File file = new File(baseFolder + File.separator + nombreArch);
            file.getParentFile().mkdirs();
            FileOutputStream fos = new FileOutputStream(file);


            AdminSQLiteOpenHelper adminSQLiteOpenHelper = new AdminSQLiteOpenHelper(getContext(), "dbSistema", null, 1);
            SQLiteDatabase db = adminSQLiteOpenHelper.getReadableDatabase();

            String query = "SELECT idPedido, codigoVendedor, nombreVendedor, codigoCliente, nombreCliente, fechaPedido, comentariosPedido " +
                    "FROM pedidos";
            Cursor cursor = db.rawQuery(query, null);
            int cont = 0;
            int idPedidoAnterior = 0;

            boolean primerInsert = true;
            String linea = "";

            while (cursor.moveToNext()) {
                int idPedido = cursor.getInt(0);
                int codigoVendedor = cursor.getInt(1);
                String nombreVendedor = cursor.getString(2);
                int codigoCliente = cursor.getInt(3);
                String nombreCliente = cursor.getString(4);
                int fechaPedido = cursor.getInt(5);
                String comentariosPedido = cursor.getString(6);

                if (idPedidoAnterior != idPedido) {
                    idPedidoAnterior = idPedido;
                    linea = "idPedido, codigoVendedor, nombreVendedor, codigoCliente, nombreCliente, fechaPedido, comentariosPedido" + "\n";
                    fos.write(linea.getBytes());
                    linea = idPedido + "," + codigoVendedor + "," + nombreVendedor + "," + codigoCliente + "," + nombreCliente + "," + fechaPedido + "," + comentariosPedido + "\n";
                    fos.write(linea.getBytes());
                }


                ArrayList<Articulo> listaArticulos = new ArrayList<>();
                SQLiteDatabase dbArt = adminSQLiteOpenHelper.getReadableDatabase();
                String queryArt = "SELECT codigoProducto, nombreProducto, cantidadProducto, precioProducto " +
                                    "FROM productosPedidos " +
                                    "WHERE idPedido = " + idPedido ;
                Cursor cursorArt = dbArt.rawQuery(queryArt, null);
                primerInsert = true;
                while (cursorArt.moveToNext()) {
                    if (primerInsert) {
                        primerInsert = false;
                        linea = "codigoProducto, nombreProducto, cantidadProducto, precioProducto" + "\n";
                        fos.write(linea.getBytes());
                    }

                    int codigo = cursorArt.getInt(0);
                    String descripcion = cursorArt.getString(1);
                    int cantidad = cursorArt.getInt(2);
                    double precio = cursorArt.getDouble(3);

                    linea = codigo + "," + descripcion + "," + cantidad + "," + precio + "\n";
                    fos.write(linea.getBytes());
                }
                linea =  "\n";;
                fos.write(linea.getBytes());
                fos.write(linea.getBytes());
                cursorArt.close();
                cont++;
            }

            cursor.close();


            fos.flush();
            fos.close();

            Toast.makeText(contexto, "Pedido generado en la carpeta de 'Descargas'", Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            Log.i("FILE-ERROR: ", e.getMessage());
        }

    }


    /*
    @Override
    public void onClick(View v) {
        NuevoPedidoFragment nuevoPedidoFragment = new NuevoPedidoFragment();
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.contenedor, nuevoPedidoFragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
    */
}
