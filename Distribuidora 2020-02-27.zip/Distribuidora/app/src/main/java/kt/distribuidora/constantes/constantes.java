package kt.distribuidora.constantes;

public class constantes {

    //preferencias
    //public static String distribuidoraConfig = "distribuidora.config";

    //constantes
    public static String passwordKt = "kiwitech2020";
    public static String CONFIG_NOT_FOUND = "CONFIG_NOT_FOUND";
    public static String CONFIG_FOUND = "CONFIG_FOUND";
    public static int RESULT_CERRAR_SESION = 111;
    public static int RESULT_MAIN_ACTIVITY = 222;
    public static int RESULT_CLIENTES_FILE = 170;
    public static int RESULT_ARTICULOS_FILE = 171;
    public static int RESULT_VENDEDORES_FILE = 172;
    public static int RESULT_CATEGORIAS_FILE = 173;

    public static int RESULT_NUEVO_PEDIDO = 300;


}
